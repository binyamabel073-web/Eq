package com.example.data.remote

import android.util.Log
import com.example.data.model.StremioAddonManifest
import com.example.data.model.StremioCatalog
import com.example.data.model.StremioMetaDetail
import com.example.data.model.StremioMetaItem
import com.example.data.model.StremioStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object StremioHttpClient {
    private const val TAG = "StremioHttpClient"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private suspend fun getRequestAsString(url: String): String? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .build()
            
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    response.body?.string()
                } else {
                    Log.e(TAG, "Request failed for url: $url, code: ${response.code}")
                    null
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error executing request for url: $url", e)
            null
        }
    }

    /**
     * Fetch manifest of a Stremio addon.
     */
    suspend fun fetchManifest(addonUrl: String): StremioAddonManifest? {
        var sanitizedUrl = addonUrl.trim()
        if (!sanitizedUrl.startsWith("http://") && !sanitizedUrl.startsWith("https://")) {
            sanitizedUrl = "https://$sanitizedUrl"
        }
        if (!sanitizedUrl.endsWith("/manifest.json")) {
            // Remove trailing slash if exists, and append manifest.json
            sanitizedUrl = sanitizedUrl.removeSuffix("/") + "/manifest.json"
        }

        Log.d(TAG, "Fetching manifest from: $sanitizedUrl")
        val jsonStr = getRequestAsString(sanitizedUrl) ?: return null
        return try {
            StremioAddonManifest.fromJson(sanitizedUrl, jsonStr)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse manifest from $sanitizedUrl", e)
            null
        }
    }

    /**
     * Fetch items from an addon catalog.
     */
    suspend fun fetchCatalog(
        addonUrl: String,
        type: String,
        catalogId: String,
        searchQuery: String? = null
    ): List<StremioMetaItem> {
        // Base Url (e.g., https://v3-cinemeta.strem.io/manifest.json -> https://v3-cinemeta.strem.io)
        val baseUrl = addonUrl.removeSuffix("/manifest.json").removeSuffix("/")
        
        val url = if (!searchQuery.isNullOrBlank()) {
            val encodedQuery = withContext(Dispatchers.IO) { URLEncoder.encode(searchQuery, "UTF-8") }
            "$baseUrl/catalog/$type/$catalogId/search=$encodedQuery.json"
        } else {
            "$baseUrl/catalog/$type/$catalogId.json"
        }

        Log.d(TAG, "Fetching catalog from: $url")
        val jsonStr = getRequestAsString(url) ?: return emptyList()
        return try {
            val json = JSONObject(jsonStr)
            val metasArr = json.optJSONArray("metas") ?: JSONArray()
            val list = mutableListOf<StremioMetaItem>()
            for (i in 0 until metasArr.length()) {
                val obj = metasArr.getJSONObject(i)
                list.add(StremioMetaItem.fromJson(obj))
            }
            list
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse catalog from $url", e)
            emptyList()
        }
    }

    /**
     * Fetch metadata details for an IMDb/Stremio content ID.
     */
    suspend fun fetchMetaDetail(addonUrl: String, type: String, id: String): StremioMetaDetail? {
        val baseUrl = addonUrl.removeSuffix("/manifest.json").removeSuffix("/")
        val url = "$baseUrl/meta/$type/$id.json"

        Log.d(TAG, "Fetching meta detail from: $url")
        val jsonStr = getRequestAsString(url) ?: return null
        return try {
            val json = JSONObject(jsonStr)
            val metaObj = json.optJSONObject("meta") ?: return null
            StremioMetaDetail.fromJson(metaObj)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse meta detail from $url", e)
            null
        }
    }

    /**
     * Fetch video streams for an item.
     * ID is either imdbId (movies) or imdbId:season:episode (series).
     */
    suspend fun fetchStreams(addonUrl: String, type: String, id: String, addonName: String? = null): List<StremioStream> {
        val baseUrl = addonUrl.removeSuffix("/manifest.json").removeSuffix("/")
        val url = "$baseUrl/stream/$type/$id.json"

        Log.d(TAG, "Fetching streams from: $url")
        val jsonStr = getRequestAsString(url) ?: return emptyList()
        return try {
            val json = JSONObject(jsonStr)
            val streamsArr = json.optJSONArray("streams") ?: return emptyList()
            val streamsList = mutableListOf<StremioStream>()
            for (i in 0 until streamsArr.length()) {
                val streamObj = streamsArr.getJSONObject(i)
                streamsList.add(StremioStream.fromJson(streamObj, addonName))
            }
            streamsList
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse streams from $url", e)
            emptyList()
        }
    }

    suspend fun fetchCommunityAddons(): List<StremioAddonManifest> = withContext(Dispatchers.IO) {
        val urls = listOf(
            "https://raw.githubusercontent.com/community-addons/stremio-addons/master/addons.json",
            "https://v3-addons.strem.io/addons.json"
        )
        val list = mutableListOf<StremioAddonManifest>()
        
        for (url in urls) {
            try {
                val jsonStr = getRequestAsString(url) ?: continue
                if (jsonStr.trim().startsWith("[")) {
                    val arr = JSONArray(jsonStr)
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        val manifestObj = item.optJSONObject("manifest")
                        val transportUrl = item.optString("transportUrl", "")
                        
                        if (manifestObj != null && transportUrl.isNotEmpty()) {
                            try {
                                val manifest = StremioAddonManifest.fromJson(transportUrl, manifestObj.toString())
                                if (list.none { it.url == manifest.url }) {
                                    list.add(manifest)
                                }
                            } catch (e: Exception) {
                                // Individual parse error should not halt processing
                            }
                        }
                    }
                } else if (jsonStr.trim().startsWith("{")) {
                    val obj = JSONObject(jsonStr)
                    val arr = obj.optJSONArray("addons")
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val item = arr.getJSONObject(i)
                            val manifestObj = item.optJSONObject("manifest")
                            val transportUrl = item.optString("transportUrl", "")
                            if (manifestObj != null && transportUrl.isNotEmpty()) {
                                try {
                                    val manifest = StremioAddonManifest.fromJson(transportUrl, manifestObj.toString())
                                    if (list.none { it.url == manifest.url }) {
                                        list.add(manifest)
                                    }
                                } catch (e: Exception) {
                                    // Ignore individual parsing errors
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching community addons from $url", e)
            }
        }
        
        // Ensure Torrentio and other critical streaming sources are ALWAYS included
        val fallbackPopular = listOf(
            Triple("Torrentio Lite", "Torrent provider listing cached streams directly for movies and TV shows.", "https://torrentio.strem.fun/lite/manifest.json"),
            Triple("Torrentio RD/All", "Torrent provider listing cached streams directly for movies and TV shows with RealDebrid/AllDebrid support.", "https://torrentio.strem.fun/manifest.json"),
            Triple("CyberFlix Catalog", "Stremio Addon for Netlix, Disney+, HBO Max, Apple TV+, etc.", "https://cyberflix.strem.io/manifest.json"),
            Triple("SuperFlix", "Provides clean streams for many popular movies and series.", "https://superflix.strem.io/manifest.json")
        )
        
        for (fb in fallbackPopular) {
            if (list.none { it.url == fb.third }) {
                list.add(
                    StremioAddonManifest(
                        url = fb.third,
                        id = "fallback.${fb.first.lowercase().replace(" ", "")}",
                        version = "1.0.0",
                        name = fb.first,
                        description = fb.second,
                        icon = null,
                        logo = null,
                        types = listOf("movie", "series"),
                        resources = listOf("stream", "catalog"),
                        catalogs = emptyList()
                    )
                )
            }
        }
        
        list
    }
}
