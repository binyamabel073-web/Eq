package com.example.data.model

import org.json.JSONArray
import org.json.JSONObject

data class StremioAddonManifest(
    val url: String, // Base manifest.json URL
    val id: String,
    val version: String,
    val name: String,
    val description: String?,
    val icon: String?,
    val logo: String?,
    val types: List<String>,
    val resources: List<String>, // "catalog", "meta", "stream", etc.
    val catalogs: List<StremioCatalog>
) {
    companion object {
        fun fromJson(manifestUrl: String, jsonStr: String): StremioAddonManifest {
            val json = JSONObject(jsonStr)
            
            // Parse resources: can be strings or objects
            val resourcesList = mutableListOf<String>()
            val resourcesArr = json.optJSONArray("resources")
            if (resourcesArr != null) {
                for (i in 0 until resourcesArr.length()) {
                    val item = resourcesArr.get(i)
                    if (item is String) {
                        resourcesList.add(item)
                    } else if (item is JSONObject) {
                        val name = item.optString("name")
                        if (name.isNotEmpty()) {
                            resourcesList.add(name)
                        }
                    }
                }
            }

            // Parse types
            val typesList = mutableListOf<String>()
            val typesArr = json.optJSONArray("types")
            if (typesArr != null) {
                for (i in 0 until typesArr.length()) {
                    typesList.add(typesArr.getString(i))
                }
            }

            // Parse catalogs
            val catalogsList = mutableListOf<StremioCatalog>()
            val catalogsArr = json.optJSONArray("catalogs")
            if (catalogsArr != null) {
                for (i in 0 until catalogsArr.length()) {
                    val catObj = catalogsArr.getJSONObject(i)
                    catalogsList.add(StremioCatalog.fromJson(catObj))
                }
            }

            return StremioAddonManifest(
                url = manifestUrl,
                id = json.getString("id"),
                version = json.getString("version"),
                name = json.getString("name"),
                description = json.optNullableString("description"),
                icon = json.optNullableString("icon"),
                logo = json.optNullableString("logo"),
                types = typesList,
                resources = resourcesList,
                catalogs = catalogsList
            )
        }
    }
}

data class StremioCatalog(
    val type: String,
    val id: String,
    val name: String,
    val extra: List<StremioCatalogExtra> = emptyList()
) {
    companion object {
        fun fromJson(json: JSONObject): StremioCatalog {
            val extraList = mutableListOf<StremioCatalogExtra>()
            val extraArr = json.optJSONArray("extra")
            if (extraArr != null) {
                for (i in 0 until extraArr.length()) {
                    val extraObj = extraArr.optJSONObject(i)
                    if (extraObj != null) {
                        extraList.add(StremioCatalogExtra.fromJson(extraObj))
                    }
                }
            } else {
                // Sometime extra is object-based or missing
                val extraSupported = json.optJSONArray("extraSupported")
                if (extraSupported != null) {
                    for (i in 0 until extraSupported.length()) {
                        val name = extraSupported.getString(i)
                        val isRequired = json.optJSONArray("extraRequired")?.toString()?.contains(name) == true
                        extraList.add(StremioCatalogExtra(name = name, isRequired = isRequired, options = null))
                    }
                }
            }

            return StremioCatalog(
                type = json.getString("type"),
                id = json.getString("id"),
                name = json.optString("name", json.getString("id")),
                extra = extraList
            )
        }
    }
}

data class StremioCatalogExtra(
    val name: String,
    val isRequired: Boolean,
    val options: List<String>?
) {
    companion object {
        fun fromJson(json: JSONObject): StremioCatalogExtra {
            val optionsList = mutableListOf<String>()
            val optionsArr = json.optJSONArray("options")
            if (optionsArr != null) {
                for (i in 0 until optionsArr.length()) {
                    optionsList.add(optionsArr.getString(i))
                }
            }
            return StremioCatalogExtra(
                name = json.getString("name"),
                isRequired = json.optBoolean("isRequired", false),
                options = if (optionsList.isNotEmpty()) optionsList else null
            )
        }
    }
}

data class StremioMetaItem(
    val id: String,
    val type: String,
    val name: String,
    val poster: String?,
    val background: String? = null,
    val logo: String? = null,
    val description: String? = null,
    val releaseInfo: String? = null,
    val imdbRating: String? = null,
    val genres: List<String> = emptyList()
) {
    companion object {
        fun fromJson(json: JSONObject): StremioMetaItem {
            val genresList = mutableListOf<String>()
            val genresArr = json.optJSONArray("genres")
            if (genresArr != null) {
                for (i in 0 until genresArr.length()) {
                    genresList.add(genresArr.getString(i))
                }
            }
            return StremioMetaItem(
                id = json.getString("id"),
                type = json.getString("type"),
                name = json.getString("name"),
                poster = json.optNullableString("poster"),
                background = json.optNullableString("background"),
                logo = json.optNullableString("logo"),
                description = json.optNullableString("description"),
                releaseInfo = json.optNullableString("releaseInfo"),
                imdbRating = json.optNullableString("imdbRating"),
                genres = genresList
            )
        }

        fun fromJsonArray(jsonArrayStr: String): List<StremioMetaItem> {
            val items = mutableListOf<StremioMetaItem>()
            val arr = JSONArray(jsonArrayStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                items.add(fromJson(obj))
            }
            return items
        }
    }
}

data class StremioMetaDetail(
    val id: String,
    val type: String,
    val name: String,
    val poster: String?,
    val background: String?,
    val logo: String?,
    val description: String?,
    val releaseInfo: String?,
    val imdbRating: String?,
    val genres: List<String>,
    val videos: List<StremioVideo> = emptyList()
) {
    companion object {
        fun fromJson(json: JSONObject): StremioMetaDetail {
            val genresList = mutableListOf<String>()
            val genresArr = json.optJSONArray("genres")
            if (genresArr != null) {
                for (i in 0 until genresArr.length()) {
                    genresList.add(genresArr.getString(i))
                }
            }

            val videosList = mutableListOf<StremioVideo>()
            val videosArr = json.optJSONArray("videos")
            if (videosArr != null) {
                for (i in 0 until videosArr.length()) {
                    val vidObj = videosArr.getJSONObject(i)
                    videosList.add(StremioVideo.fromJson(vidObj))
                }
            }

            return StremioMetaDetail(
                id = json.getString("id"),
                type = json.getString("type"),
                name = json.getString("name"),
                poster = json.optNullableString("poster"),
                background = json.optNullableString("background"),
                logo = json.optNullableString("logo"),
                description = json.optNullableString("description"),
                releaseInfo = json.optNullableString("releaseInfo"),
                imdbRating = json.optNullableString("imdbRating"),
                genres = genresList,
                videos = videosList
            )
        }
    }
}

data class StremioVideo(
    val id: String,
    val title: String,
    val season: Int,
    val episode: Int,
    val released: String? = null,
    val thumbnail: String? = null
) {
    companion object {
        fun fromJson(json: JSONObject): StremioVideo {
            return StremioVideo(
                id = json.getString("id"),
                title = json.optString("title", json.optString("name", "Episode " + json.optInt("episode", 1))),
                season = json.optInt("season", 0),
                episode = json.optInt("episode", json.optInt("number", 0)),
                released = json.optNullableString("released"),
                thumbnail = json.optNullableString("thumbnail")
            )
        }
    }
}

data class StremioStream(
    val name: String?,
    val title: String,
    val url: String?,
    val infoHash: String? = null,
    val fileIdx: Int? = null,
    val externalUrl: String? = null
) {
    companion object {
        fun fromJson(json: JSONObject, addonName: String? = null): StremioStream {
            return StremioStream(
                name = json.optNullableString("name") ?: addonName,
                title = json.optString("title", "Stream Source"),
                url = json.optNullableString("url"),
                infoHash = json.optNullableString("infoHash"),
                fileIdx = if (json.has("fileIdx")) json.getInt("fileIdx") else null,
                externalUrl = json.optNullableString("externalUrl")
            )
        }
    }
}

fun JSONObject.optNullableString(key: String): String? {
    return if (this.isNull(key)) null else this.optString(key)
}
