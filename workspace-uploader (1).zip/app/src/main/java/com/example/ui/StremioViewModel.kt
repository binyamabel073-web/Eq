package com.example.ui

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AddonEntity
import com.example.data.local.AppDatabase
import com.example.data.local.WatchItemEntity
import com.example.data.model.StremioMetaDetail
import com.example.data.model.StremioMetaItem
import com.example.data.model.StremioStream
import com.example.data.model.StremioVideo
import com.example.data.repository.StremioRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

import com.example.data.local.DownloadEntity

class StremioViewModel(
    application: Application,
    private val repository: StremioRepository
) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "StremioViewModel"
    }

    // Downloads list
    val downloads: StateFlow<List<DownloadEntity>> = repository.allDownloadsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Installed Addons
    val addons: StateFlow<List<AddonEntity>> = repository.allAddonsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Watch list & history
    val favorites: StateFlow<List<WatchItemEntity>> = repository.favoritesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val history: StateFlow<List<WatchItemEntity>> = repository.historyFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Home Catalog Lists
    private val _homeMovies = MutableStateFlow<List<StremioMetaItem>>(emptyList())
    val homeMovies = _homeMovies.asStateFlow()

    private val _homeSeries = MutableStateFlow<List<StremioMetaItem>>(emptyList())
    val homeSeries = _homeSeries.asStateFlow()

    private val _featuredItem = MutableStateFlow<StremioMetaItem?>(null)
    val featuredItem = _featuredItem.asStateFlow()

    private val _homeLoading = MutableStateFlow(false)
    val homeLoading = _homeLoading.asStateFlow()

    // Search Lists
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _searchMovies = MutableStateFlow<List<StremioMetaItem>>(emptyList())
    val searchMovies = _searchMovies.asStateFlow()

    private val _searchSeries = MutableStateFlow<List<StremioMetaItem>>(emptyList())
    val searchSeries = _searchSeries.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching = _isSearching.asStateFlow()

    // Details State
    private val _selectedDetail = MutableStateFlow<StremioMetaDetail?>(null)
    val selectedDetail = _selectedDetail.asStateFlow()

    private val _isLoadingDetail = MutableStateFlow(false)
    val isLoadingDetail = _isLoadingDetail.asStateFlow()

    private val _isFavoriteState = MutableStateFlow(false)
    val isFavoriteState = _isFavoriteState.asStateFlow()

    // Streams State
    private val _streams = MutableStateFlow<List<StremioStream>>(emptyList())
    val streams = _streams.asStateFlow()

    private val _isLoadingStreams = MutableStateFlow(false)
    val isLoadingStreams = _isLoadingStreams.asStateFlow()

    // Active Playback State
    private val _activeStream = MutableStateFlow<StremioStream?>(null)
    val activeStream = _activeStream.asStateFlow()

    // VLC Player Redirection Settings
    private val prefs = application.getSharedPreferences("flixon_prefs", Context.MODE_PRIVATE)

    private val _redirectTorrentioToVlc = MutableStateFlow(prefs.getBoolean("redirect_torrentio_to_vlc", true))
    val redirectTorrentioToVlc = _redirectTorrentioToVlc.asStateFlow()

    private val _alwaysUseVlc = MutableStateFlow(prefs.getBoolean("always_use_vlc", false))
    val alwaysUseVlc = _alwaysUseVlc.asStateFlow()

    private val _useStreamingServer = MutableStateFlow(prefs.getBoolean("use_streaming_server", true))
    val useStreamingServer = _useStreamingServer.asStateFlow()

    private val _streamingServerUrl = MutableStateFlow(prefs.getString("streaming_server_url", "http://127.0.0.1:11470") ?: "http://127.0.0.1:11470")
    val streamingServerUrl = _streamingServerUrl.asStateFlow()

    fun setRedirectTorrentioToVlc(enabled: Boolean) {
        _redirectTorrentioToVlc.value = enabled
        prefs.edit().putBoolean("redirect_torrentio_to_vlc", enabled).apply()
    }

    fun setAlwaysUseVlc(enabled: Boolean) {
        _alwaysUseVlc.value = enabled
        prefs.edit().putBoolean("always_use_vlc", enabled).apply()
    }

    fun setUseStreamingServer(enabled: Boolean) {
        _useStreamingServer.value = enabled
        prefs.edit().putBoolean("use_streaming_server", enabled).apply()
    }

    fun setStreamingServerUrl(url: String) {
        _streamingServerUrl.value = url
        prefs.edit().putString("streaming_server_url", url).apply()
    }

    init {
        viewModelScope.launch {
            // Initializing defaults
            repository.initDefaultAddons()
            
            // Listen to addons list change to automatically reload catalogs
            addons.collectLatest { list ->
                if (list.isNotEmpty()) {
                    loadHomeCatalogs()
                }
            }
        }
    }

    fun loadHomeCatalogs() {
        viewModelScope.launch {
            _homeLoading.value = true
            try {
                // Fetch movie items from enabled catalogs
                val movies = repository.getCatalogItems(type = "movie", catalogId = "top")
                _homeMovies.value = movies
                
                // Fetch series items
                val series = repository.getCatalogItems(type = "series", catalogId = "top")
                _homeSeries.value = series

                // Set featured banner
                if (movies.isNotEmpty()) {
                    _featuredItem.value = movies.shuffled().firstOrNull()
                } else if (series.isNotEmpty()) {
                    _featuredItem.value = series.shuffled().firstOrNull()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error loading home catalogs", e)
            } finally {
                _homeLoading.value = false
            }
        }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
        if (query.isBlank()) {
            _searchMovies.value = emptyList()
            _searchSeries.value = emptyList()
            return
        }

        viewModelScope.launch {
            _isSearching.value = true
            try {
                val movieResults = repository.getCatalogItems(type = "movie", catalogId = "top", searchQuery = query)
                _searchMovies.value = movieResults

                val seriesResults = repository.getCatalogItems(type = "series", catalogId = "top", searchQuery = query)
                _searchSeries.value = seriesResults
            } catch (e: Exception) {
                Log.e(TAG, "Error searching for $query", e)
            } finally {
                _isSearching.value = false
            }
        }
    }

    private var favoriteStatusJob: kotlinx.coroutines.Job? = null

    fun loadDetail(type: String, id: String) {
        favoriteStatusJob?.cancel()
        viewModelScope.launch {
            _isLoadingDetail.value = true
            _selectedDetail.value = null
            _streams.value = emptyList()
            try {
                val detail = repository.getMetaDetail(type, id)
                _selectedDetail.value = detail
                
                if (detail != null) {
                    // Collect favorite status flow in a separate coroutine so it does not block the loader
                    favoriteStatusJob = viewModelScope.launch {
                        repository.getWatchItemFlow(detail.id).collectLatest { entity ->
                            _isFavoriteState.value = entity?.isFavorite ?: false
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error loading details for $id", e)
            } finally {
                _isLoadingDetail.value = false
            }
        }
    }

    fun toggleFavorite(detail: StremioMetaDetail) {
        viewModelScope.launch {
            val res = repository.toggleFavorite(detail)
            _isFavoriteState.value = res
        }
    }

    /**
     * Load stream links for a movie or series episode.
     */
    fun loadStreams(type: String, id: String) {
        viewModelScope.launch {
            _isLoadingStreams.value = true
            _streams.value = emptyList()
            try {
                val fetchedStreams = repository.getStreams(type, id)
                _streams.value = fetchedStreams
            } catch (e: Exception) {
                Log.e(TAG, "Error loading streams for $id", e)
            } finally {
                _isLoadingStreams.value = false
            }
        }
    }

    fun selectStream(stream: StremioStream, detail: StremioMetaDetail, video: StremioVideo? = null) {
        _activeStream.value = stream
        
        // Log watch history
        viewModelScope.launch {
            repository.saveToHistory(
                id = detail.id,
                type = detail.type,
                name = detail.name,
                poster = detail.poster,
                background = detail.background,
                rating = detail.imdbRating,
                genres = detail.genres.joinToString(","),
                description = detail.description,
                episodeId = video?.id,
                progress = 0.1f
            )
        }
    }

    fun stopPlayback() {
        _activeStream.value = null
    }

    fun startDownloadStream(detail: StremioMetaDetail, video: StremioVideo?, stream: StremioStream) {
        val downloadId = stream.url ?: "stream_hash_${(stream.title + (video?.id ?: "")).hashCode()}"
        
        viewModelScope.launch {
            val existing = repository.getDownloadById(downloadId)
            if (existing != null && (existing.status == "Completed" || existing.status == "Downloading")) {
                return@launch
            }

            // Estimate simulated file size
            val size = when {
                stream.title.contains("2160p", ignoreCase = true) || stream.title.contains("4k", ignoreCase = true) -> "3.2 GB"
                stream.title.contains("1080p", ignoreCase = true) -> "1.4 GB"
                stream.title.contains("720p", ignoreCase = true) -> "850 MB"
                else -> "480 MB"
            }

            val titleText = if (video != null) {
                "${detail.name} - S${video.season}E${video.episode}: ${video.title}"
            } else {
                detail.name
            }

            val entity = DownloadEntity(
                id = downloadId,
                itemId = detail.id,
                type = detail.type,
                itemName = detail.name,
                itemPoster = detail.poster,
                title = titleText,
                streamUrl = stream.url ?: "",
                status = "Downloading",
                progress = 0.0f,
                fileSize = size,
                downloadedAt = System.currentTimeMillis()
            )

            repository.saveDownload(entity)

            // Launch simulated download progress in background coroutine
            launch {
                var currentProgress = 0.0f
                while (currentProgress < 1.0f) {
                    kotlinx.coroutines.delay(1000)
                    currentProgress += (0.1f + (Math.random() * 0.08).toFloat())
                    if (currentProgress > 1.0f) currentProgress = 1.0f
                    
                    val currentStatus = if (currentProgress >= 1.0f) "Completed" else "Downloading"
                    repository.updateDownloadProgress(downloadId, currentProgress, currentStatus)
                }
            }
        }
    }

    fun deleteDownload(id: String) {
        viewModelScope.launch {
            repository.deleteDownload(id)
        }
    }

    fun playDownloadedStream(download: DownloadEntity) {
        _activeStream.value = StremioStream(
            name = download.itemName,
            title = download.title,
            url = download.streamUrl,
            infoHash = null,
            fileIdx = null
        )
    }

    // --- Addons Manager Functions ---

    private val _communityAddons = MutableStateFlow<List<com.example.data.model.StremioAddonManifest>>(emptyList())
    val communityAddons = _communityAddons.asStateFlow()

    private val _isLoadingCommunityAddons = MutableStateFlow(false)
    val isLoadingCommunityAddons = _isLoadingCommunityAddons.asStateFlow()

    fun loadCommunityAddons() {
        viewModelScope.launch {
            _isLoadingCommunityAddons.value = true
            try {
                val list = repository.getCommunityAddons()
                _communityAddons.value = list
            } catch (e: Exception) {
                Log.e(TAG, "Error loading community addons", e)
            } finally {
                _isLoadingCommunityAddons.value = false
            }
        }
    }

    fun installAddon(url: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val success = repository.installAddon(url)
            if (success) {
                onSuccess()
                loadHomeCatalogs()
            } else {
                onError("Failed to fetch or parse Stremio add-on manifest. Make sure the URL is correct.")
            }
        }
    }

    fun uninstallAddon(url: String) {
        viewModelScope.launch {
            repository.deleteAddon(url)
            loadHomeCatalogs()
        }
    }

    fun toggleAddon(url: String, isEnabled: Boolean) {
        viewModelScope.launch {
            repository.toggleAddon(url, isEnabled)
            loadHomeCatalogs()
        }
    }

    class Factory(
        private val application: Application,
        private val repository: StremioRepository
    ) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(StremioViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return StremioViewModel(application, repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
