package com.example.ui.screens

import android.content.Context
import android.content.pm.ActivityInfo
import android.util.Log
import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.extractor.DefaultExtractorsFactory
import okhttp3.OkHttpClient
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import com.example.data.model.StremioStream

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    stream: StremioStream,
    viewModel: com.example.ui.StremioViewModel,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val useStreamingServer = viewModel.useStreamingServer.collectAsState().value
    val streamingServerUrl = viewModel.streamingServerUrl.collectAsState().value

    val parsedInfoHash = remember(stream) {
        if (!stream.infoHash.isNullOrBlank()) {
            stream.infoHash.lowercase()
        } else if (stream.url?.startsWith("magnet:", ignoreCase = true) == true) {
            val magnetUrl = stream.url
            val prefix = "xt=urn:btih:"
            val index = magnetUrl.indexOf(prefix, ignoreCase = true)
            if (index != -1) {
                val start = index + prefix.length
                var end = magnetUrl.indexOf('&', start)
                if (end == -1) {
                    end = magnetUrl.length
                }
                magnetUrl.substring(start, end).trim().lowercase()
            } else {
                null
            }
        } else {
            null
        }
    }

    val videoUrl = if (useStreamingServer && !parsedInfoHash.isNullOrBlank()) {
        val serverUrl = streamingServerUrl.trimEnd('/')
        "${serverUrl}/${parsedInfoHash}/${stream.fileIdx ?: 0}"
    } else if (!stream.url.isNullOrBlank()) {
        stream.url
    } else {
        null
    }

    // Force landscape orientation for immersive full screen video player
    DisposableEffect(Unit) {
        val activity = context as? android.app.Activity
        val originalOrientation = activity?.requestedOrientation
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE
        
        onDispose {
            activity?.requestedOrientation = originalOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (videoUrl.isNullOrBlank()) {
            // Torrent stream info fallback
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp)
                    .align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Torrent stream",
                    tint = Color(0xFFFFB300),
                    modifier = Modifier.size(54.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Torrent Engine Required",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "This link relies on peer-to-peer BitTorrent networks (infoHash: ${parsedInfoHash ?: "unknown"}). To stream this torrent, please copy the magnet link and stream using an external torrent player like VLC, Nova, or Stremio.",
                    color = Color.LightGray,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp,
                    modifier = Modifier.fillMaxWidth(0.8f)
                )
                Spacer(modifier = Modifier.height(24.dp))
                androidx.compose.foundation.layout.Row(
                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(16.dp)
                ) {
                    Button(
                        onClick = onBackClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.DarkGray,
                            contentColor = Color.White
                        ),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                    ) {
                        Text(text = "Go Back")
                    }

                    if (!stream.infoHash.isNullOrBlank()) {
                        Button(
                            onClick = {
                                val magnetUrl = "magnet:?xt=urn:btih:${stream.infoHash}"
                                val played = com.example.ui.VlcHelper.playInVlc(context, magnetUrl, stream.title)
                                if (played) {
                                    onBackClick()
                                } else {
                                    android.widget.Toast.makeText(context, "Could not open VLC Player. Make sure it is installed.", android.widget.Toast.LENGTH_LONG).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFFF8800), // VLC Orange!
                                contentColor = Color.White
                            ),
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                        ) {
                            androidx.compose.foundation.layout.Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "VLC icon",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "Open Magnet in VLC", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        } else {
            // Jetpack Media3 ExoPlayer Stream Engine
            val playbackError = remember { androidx.compose.runtime.mutableStateOf<String?>(null) }
            val coroutineScope = rememberCoroutineScope()
            
            // Premium control states
            val resizeModeState = remember { androidx.compose.runtime.mutableStateOf(0) } // 0 = Fit, 1 = Fill, 2 = Zoom
            val playbackSpeedState = remember { androidx.compose.runtime.mutableStateOf(1.0f) }
            
            // Double-tap indicators
            val showRewindIndicator = remember { androidx.compose.runtime.mutableStateOf(false) }
            val showForwardIndicator = remember { androidx.compose.runtime.mutableStateOf(false) }
            
            // PlayerView reference to toggle controls
            var playerViewRef by remember { androidx.compose.runtime.mutableStateOf<PlayerView?>(null) }

            val exoPlayer = remember {
                // Configure a lenient Extractor Factory that supports constant bitrate seeking for arbitrary video streams
                val extractorsFactory = DefaultExtractorsFactory().apply {
                    setConstantBitrateSeekingEnabled(true)
                }

                // Setup an all-trusting Trust Manager for unverified / expired SSL video servers
                val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                    override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                    override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                    override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
                })

                val sslContext = SSLContext.getInstance("SSL")
                sslContext.init(null, trustAllCerts, SecureRandom())
                val sslSocketFactory = sslContext.socketFactory

                // Configure OkHttpClient to trust all certs and recursively follow redirects across HTTP & HTTPS protocols while injecting headers
                val okHttpClient = OkHttpClient.Builder()
                    .sslSocketFactory(sslSocketFactory, trustAllCerts[0] as X509TrustManager)
                    .hostnameVerifier { _, _ -> true }
                    .addInterceptor { chain ->
                        var request = chain.request()
                        val requestBuilder = request.newBuilder()
                            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                        
                        if (request.header("Referer") == null) {
                            val url = request.url
                            val referer = "${url.scheme}://${url.host}/"
                            requestBuilder.header("Referer", referer)
                        }
                        
                        request = requestBuilder.build()
                        var response = chain.proceed(request)
                        var tryCount = 0
                        
                        while ((response.code == 301 || response.code == 302 || response.code == 303 || response.code == 307 || response.code == 308) && tryCount < 5) {
                            val redirectUrl = response.header("Location") ?: break
                            response.close()
                            
                            val redirectRequestBuilder = request.newBuilder()
                                .url(redirectUrl)
                                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                            
                            val parsedUrl = redirectUrl.toHttpUrlOrNull()
                            if (parsedUrl != null) {
                                redirectRequestBuilder.header("Referer", "${parsedUrl.scheme}://${parsedUrl.host}/")
                            }
                            
                            request = redirectRequestBuilder.build()
                            response = chain.proceed(request)
                            tryCount++
                        }
                        response
                    }
                    .build()

                val dataSourceFactory = DefaultDataSource.Factory(
                    context,
                    OkHttpDataSource.Factory(okHttpClient)
                )

                // Create a media source factory configured with the custom data source and extractors
                val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory, extractorsFactory)

                ExoPlayer.Builder(context)
                    .setMediaSourceFactory(mediaSourceFactory)
                    .build().apply {
                        // Dynamically build appropriate media source based on stream protocol/format
                        val uriString = videoUrl.lowercase()
                        val mediaItem = MediaItem.fromUri(videoUrl)
                        val mediaSource = when {
                            uriString.startsWith("rtsp://") -> {
                                RtspMediaSource.Factory()
                                    .createMediaSource(mediaItem)
                            }
                            uriString.contains(".m3u8") || uriString.contains("m3u8") || uriString.contains("/hls/") -> {
                                HlsMediaSource.Factory(dataSourceFactory)
                                    .setAllowChunklessPreparation(true)
                                    .createMediaSource(mediaItem)
                            }
                            uriString.contains(".mpd") || uriString.contains("mpd") || uriString.contains("/dash/") -> {
                                DashMediaSource.Factory(dataSourceFactory)
                                    .createMediaSource(mediaItem)
                            }
                            else -> {
                                ProgressiveMediaSource.Factory(dataSourceFactory, extractorsFactory)
                                    .createMediaSource(mediaItem)
                            }
                        }

                        setMediaSource(mediaSource)
                        prepare()
                        playWhenReady = true
                    }
            }

            // Error listener to catch and print streaming exceptions
            DisposableEffect(exoPlayer) {
                val listener = object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        Log.e("PlayerScreen", "ExoPlayer loading exception", error)
                        playbackError.value = error.localizedMessage ?: "Playback Error"
                    }
                }
                exoPlayer.addListener(listener)
                onDispose {
                    exoPlayer.removeListener(listener)
                    exoPlayer.release()
                }
            }

            // Sync speed state to the ExoPlayer instance
            LaunchedEffect(playbackSpeedState.value) {
                exoPlayer.setPlaybackSpeed(playbackSpeedState.value)
            }

            Box(modifier = Modifier.fillMaxSize()) {
                AndroidView(
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            player = exoPlayer
                            useController = true
                            setShowSubtitleButton(true)
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            playerViewRef = this
                        }
                    },
                    update = { view ->
                        view.resizeMode = when (resizeModeState.value) {
                            1 -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL
                            2 -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                            else -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Invisible gesture detectors for Double-Tap seeking overlay
                Row(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(1f)
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onDoubleTap = {
                                        val newPos = maxOf(0L, exoPlayer.currentPosition - 10000L)
                                        exoPlayer.seekTo(newPos)
                                        showRewindIndicator.value = true
                                        coroutineScope.launch {
                                            delay(650)
                                            showRewindIndicator.value = false
                                        }
                                    },
                                    onTap = {
                                        playerViewRef?.let { pv ->
                                            if (pv.isControllerFullyVisible) pv.hideController() else pv.showController()
                                        }
                                    }
                                )
                            }
                    )
                    
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(1f)
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onDoubleTap = {
                                        val newPos = minOf(exoPlayer.duration, exoPlayer.currentPosition + 10000L)
                                        exoPlayer.seekTo(newPos)
                                        showForwardIndicator.value = true
                                        coroutineScope.launch {
                                            delay(650)
                                            showForwardIndicator.value = false
                                        }
                                    },
                                    onTap = {
                                        playerViewRef?.let { pv ->
                                            if (pv.isControllerFullyVisible) pv.hideController() else pv.showController()
                                        }
                                    }
                                )
                            }
                    )
                }

                // Beautiful overlay indicators for Double-Tap Rewind/Forward
                AnimatedVisibility(
                    visible = showRewindIndicator.value,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier.align(Alignment.CenterStart).padding(start = 64.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.5f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("◀◀", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("10s", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                AnimatedVisibility(
                    visible = showForwardIndicator.value,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier.align(Alignment.CenterEnd).padding(end = 64.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.5f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("▶▶", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("10s", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Overlap Floating Back Button at top left
            IconButton(
                onClick = onBackClick,
                modifier = Modifier
                    .padding(16.dp)
                    .size(48.dp)
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    .align(Alignment.TopStart)
                    .testTag("player_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Close player",
                    tint = Color.White
                )
            }

            if (playbackError.value != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.92f))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
                        modifier = Modifier.fillMaxWidth(0.85f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Playback Error",
                            tint = Color(0xFFE53935),
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Playback Failed",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "This Torrent stream failed to load. This typically happens because your Stremio Streaming Engine (at $streamingServerUrl) is offline or unreachable.\n\nTo play this stream, make sure Stremio is running on your phone/PC, or configure Torrentio with a debrid service (like Real-Debrid) in Torrentio settings for direct high-speed HTTP streaming.",
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 16.sp
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        androidx.compose.foundation.layout.Row(
                            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = onBackClick,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.DarkGray,
                                    contentColor = Color.White
                                )
                            ) {
                                Text("Go Back", fontSize = 11.sp)
                            }
                            
                            Button(
                                onClick = {
                                    viewModel.setUseStreamingServer(false)
                                    playbackError.value = null
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF1E88E5),
                                    contentColor = Color.White
                                )
                            ) {
                                Text("Disable Server Mode", fontSize = 11.sp)
                            }
                            
                            Button(
                                onClick = {
                                    val played = com.example.ui.VlcHelper.playInVlc(context, videoUrl, stream.title)
                                    if (played) {
                                        onBackClick()
                                    } else {
                                        android.widget.Toast.makeText(context, "Could not open VLC Player.", android.widget.Toast.LENGTH_LONG).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFFF8800),
                                    contentColor = Color.White
                                )
                            ) {
                                Text("Force VLC", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // Overlap Floating Controls at top right (Speed, Aspect Ratio, and VLC)
            androidx.compose.foundation.layout.Row(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
            ) {
                // Aspect Ratio Capsule
                Button(
                    onClick = {
                        resizeModeState.value = (resizeModeState.value + 1) % 3
                        val modeName = when (resizeModeState.value) {
                            0 -> "Fit"
                            1 -> "Stretch"
                            2 -> "Zoom"
                            else -> "Fit"
                        }
                        android.widget.Toast.makeText(context, "Aspect Ratio: $modeName", android.widget.Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Black.copy(alpha = 0.6f),
                        contentColor = Color.White
                    ),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    val modeText = when (resizeModeState.value) {
                        0 -> "Fit"
                        1 -> "Stretch"
                        2 -> "Zoom"
                        else -> "Fit"
                    }
                    Text("Aspect: $modeText", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                // Speed Capsule
                Button(
                    onClick = {
                        val newSpeed = when (playbackSpeedState.value) {
                            0.75f -> 1.0f
                            1.0f -> 1.25f
                            1.25f -> 1.5f
                            1.5f -> 2.0f
                            2.0f -> 0.5f
                            else -> 1.0f
                        }
                        playbackSpeedState.value = newSpeed
                        android.widget.Toast.makeText(context, "Playback Speed: ${newSpeed}x", android.widget.Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Black.copy(alpha = 0.6f),
                        contentColor = Color.White
                    ),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text("Speed: ${playbackSpeedState.value}x", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                // Open in VLC Button
                Button(
                    onClick = {
                        videoUrl?.let { url ->
                            val played = com.example.ui.VlcHelper.playInVlc(context, url, stream.title)
                            if (played) {
                                onBackClick() // close internal player if opened in external
                            } else {
                                android.widget.Toast.makeText(context, "Could not open VLC Player. Make sure it is installed.", android.widget.Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Black.copy(alpha = 0.6f),
                        contentColor = Color.White
                    ),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Open in VLC",
                        tint = Color(0xFFFF8800), // VLC Orange!
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Play in VLC", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
