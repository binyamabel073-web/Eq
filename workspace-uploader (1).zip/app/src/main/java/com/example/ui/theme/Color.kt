package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cinematic Obsidian & Netflix Red/Crimson Visual Identity
val MinimalBackground = Color(0xFF000000) // Netflix pure cinema black
val MinimalPrimary = Color(0xFFE50914)    // Netflix Signature vibrant red
val MinimalSecondary = Color(0xFF181818)  // Netflix Card / Control slate gray
val MinimalTertiary = Color(0xFFFF2E3B)   // Nuvio luminous neon red for accents & ratings
val MinimalOnPrimary = Color(0xFFFFFFFF)  // Contrast crisp white over primary red
val MinimalTextPrimary = Color(0xFFF5F5F7) // Beautiful off-white / platinum text
val MinimalTextSecondary = Color(0xFFB3B3B3) // Netflix classic medium-light body gray
val MinimalTextMuted = Color(0xFF737373)    // Classic muted captions gray
val MinimalSurface = Color(0xFF121212)    // Nuvio luminous card surface container
