package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri

object VlcHelper {
    fun playInVlc(context: Context, videoUrl: String, streamTitle: String): Boolean {
        val uri = Uri.parse(videoUrl)
        val scheme = uri.scheme?.lowercase() ?: ""
        val uriString = videoUrl.lowercase()

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setPackage("org.videolan.vlc")
            
            // Dynamically set correct MIME type for optimal VLC handling
            when {
                scheme.startsWith("magnet") || uriString.startsWith("magnet:") -> {
                    // Magnet link: omit MIME type so VLC triggers its built-in Torrent stream reader
                    setData(uri)
                }
                uriString.contains(".m3u8") || uriString.contains("m3u8") || uriString.contains("/hls/") -> {
                    // HLS/M3U8: set specific playlist MIME type to avoid playlist nesting errors
                    setDataAndType(uri, "application/x-mpegURL")
                }
                else -> {
                    // Progressive / direct media stream
                    setDataAndType(uri, "video/*")
                }
            }
            
            putExtra("title", streamTitle)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            val genericIntent = Intent(Intent.ACTION_VIEW).apply {
                when {
                    scheme.startsWith("magnet") || uriString.startsWith("magnet:") -> {
                        setData(uri)
                    }
                    uriString.contains(".m3u8") || uriString.contains("m3u8") || uriString.contains("/hls/") -> {
                        setDataAndType(uri, "application/x-mpegURL")
                    }
                    else -> {
                        setDataAndType(uri, "video/*")
                    }
                }
                putExtra("title", streamTitle)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(genericIntent)
                true
            } catch (ex: Exception) {
                false
            }
        }
    }
}
