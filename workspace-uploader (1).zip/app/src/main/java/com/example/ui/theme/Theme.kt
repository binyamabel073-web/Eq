package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = MinimalPrimary,
    secondary = MinimalSecondary,
    tertiary = MinimalTertiary,
    background = MinimalBackground,
    surface = MinimalBackground,
    onPrimary = MinimalOnPrimary,
    onSecondary = MinimalTextPrimary,
    onBackground = MinimalTextPrimary,
    onSurface = MinimalTextPrimary,
    surfaceVariant = MinimalSurface,
    onSurfaceVariant = MinimalTextSecondary
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
