package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.local.AppDatabase
import com.example.data.repository.StremioRepository
import com.example.ui.StremioViewModel
import com.example.ui.screens.AddonsScreen
import com.example.ui.screens.DetailScreen
import com.example.ui.screens.DownloadsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PlayerScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Create database and repository
        val database = AppDatabase.getDatabase(this)
        val repository = StremioRepository(database.addonDao(), database.watchItemDao(), database.downloadDao())

        setContent {
            MyApplicationTheme {
                // Initialize Shared ViewModel with standard Factory pattern
                val viewModel: StremioViewModel by viewModels {
                    StremioViewModel.Factory(application, repository)
                }

                val navController = rememberNavController()
                val activeStream by viewModel.activeStream.collectAsState()
                val redirectTorrentio by viewModel.redirectTorrentioToVlc.collectAsState()
                val alwaysUseVlc by viewModel.alwaysUseVlc.collectAsState()
                val useStreamingServer by viewModel.useStreamingServer.collectAsState()
                val streamingServerUrl by viewModel.streamingServerUrl.collectAsState()

                val context = androidx.compose.ui.platform.LocalContext.current
                androidx.compose.runtime.LaunchedEffect(activeStream) {
                    val stream = activeStream
                    if (stream != null) {
                        val isTorrentio = stream.name?.contains("torrentio", ignoreCase = true) == true ||
                                          stream.title.contains("torrentio", ignoreCase = true) ||
                                          !stream.infoHash.isNullOrBlank()
                        
                        if (alwaysUseVlc || (redirectTorrentio && isTorrentio)) {
                            val urlToPlay = if (!stream.url.isNullOrBlank()) {
                                stream.url
                            } else if (useStreamingServer && !stream.infoHash.isNullOrBlank()) {
                                val serverUrl = streamingServerUrl.trimEnd('/')
                                "${serverUrl}/${stream.infoHash}/${stream.fileIdx ?: 0}"
                            } else if (!stream.infoHash.isNullOrBlank()) {
                                "magnet:?xt=urn:btih:${stream.infoHash}"
                            } else {
                                null
                            }
                            
                            if (urlToPlay != null) {
                                val played = com.example.ui.VlcHelper.playInVlc(context, urlToPlay, stream.title)
                                if (played) {
                                    viewModel.stopPlayback()
                                } else {
                                    android.widget.Toast.makeText(context, "Could not open VLC Player. Falling back to internal player.", android.widget.Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    }
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                        NavHost(
                            navController = navController,
                            startDestination = "home",
                            modifier = Modifier.padding(innerPadding)
                        ) {
                            composable("home") {
                                HomeScreen(
                                    viewModel = viewModel,
                                    onNavigateToDetail = { type, id ->
                                        navController.navigate("detail/$type/$id")
                                    },
                                    onNavigateToSearch = {
                                        navController.navigate("search")
                                    },
                                    onNavigateToAddons = {
                                        navController.navigate("addons")
                                    },
                                    onNavigateToDownloads = {
                                        navController.navigate("downloads")
                                    }
                                )
                            }

                            composable("search") {
                                SearchScreen(
                                    viewModel = viewModel,
                                    onNavigateToDetail = { type, id ->
                                        navController.navigate("detail/$type/$id")
                                    },
                                    onBackClick = {
                                        navController.popBackStack()
                                    }
                                )
                            }

                            composable(
                                route = "detail/{type}/{id}",
                                arguments = listOf(
                                    navArgument("type") { type = NavType.StringType },
                                    navArgument("id") { type = NavType.StringType }
                                )
                            ) { backStackEntry ->
                                val type = backStackEntry.arguments?.getString("type").orEmpty()
                                val id = backStackEntry.arguments?.getString("id").orEmpty()

                                DetailScreen(
                                    viewModel = viewModel,
                                    type = type,
                                    id = id,
                                    onBackClick = {
                                        navController.popBackStack()
                                    },
                                    onNavigateToAddons = {
                                        navController.navigate("addons")
                                    }
                                )
                            }

                            composable("addons") {
                                AddonsScreen(
                                    viewModel = viewModel,
                                    onBackClick = {
                                        navController.popBackStack()
                                    }
                                )
                            }

                            composable("downloads") {
                                DownloadsScreen(
                                    viewModel = viewModel,
                                    onBackClick = {
                                        navController.popBackStack()
                                    }
                                )
                            }
                        }
                    }

                    // Seamless full-screen landscape media player overlay matching Netflix
                    AnimatedVisibility(
                        visible = activeStream != null,
                        enter = fadeIn(animationSpec = tween(300)),
                        exit = fadeOut(animationSpec = tween(300))
                    ) {
                        activeStream?.let { stream ->
                            PlayerScreen(
                                stream = stream,
                                viewModel = viewModel,
                                onBackClick = {
                                    viewModel.stopPlayback()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
